# EasySave
This is a Save Application created for a school project at CESI Ingineering School
This is the version 3.0 of our program. We faced difficulties to create this version and unfortunatly it was named version2.0 but it really is the 3.0 version.
We added few assets like the possibility to prioritise certain file extensions and a new window, "Save Management", where you will be able to launch the save work with a pull-down
menu with all the names of your saves.
